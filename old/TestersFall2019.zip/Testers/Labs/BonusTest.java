package lab09;

public class BonusTest {
    public static void main(String[] args) {
        Bonus.printYoungestEmployee();
    }
}
