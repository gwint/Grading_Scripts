# assignment02
NOTES ON tests
Assignment2Tester.java is the correct tester:
waitYears and  balanceAfter 
use for (int i = 0; i < numberOfYears; i++) 

Assignment2TesterAltern.java will be common 
waitYears and  balanceAfter 
use for (int i = 1; i <= numberOfYears; i++), which was used in the Lab code. It matters since when the rate changes.

Assignment2TesterAltern2.java will also be common 
waitYears and  balanceAfter have the same issue but also
yearsToBalance does not subtract year at the end of the method

