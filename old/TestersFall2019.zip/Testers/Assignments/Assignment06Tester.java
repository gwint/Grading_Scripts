package assignment06;

import org.junit.*;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.nio.file.Files;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.io.PrintWriter;
import java.io.IOException;
import java.util.Arrays;
import org.junit.Assert;
import org.junit.runners.MethodSorters;
import java.util.Map;
import java.util.HashMap;
import org.junit.rules.TestWatcher;
import org.junit.runner.Description;
import java.util.List;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class Assignment06Tester {
    @Test
    public void countryTestEnumOrder() {
        assertTrue(false);
    }

    @Test
    public void countryTestSort() {
        assertTrue(false);
    }

    @Test
    public void removeTest1() {
        assertTrue(false);
    }

    @Test
    public void removeTest2() {
        assertTrue(false);
    }

    @Test
    public void removeTest3() {
        assertTrue(false);
    }

    @Test
    public void removeTest4() {
        assertTrue(false);
    }

    @Test
    public void removeTestCount1() {
        assertTrue(false);
    }

    @Test
    public void removeTestCount2() {
        assertTrue(false);
    }

    @Test
    public void removeTestCount3() {
        assertTrue(false);
    }

    @Test
    public void removeTestCount4() {
        assertTrue(false);
    }
}
